/**********************************************************************
 * cbf_example -- read an image file and print out various parameters *
 *             Paul Ellis (ellis@ssrl.slac.stanford.edu)              *
 **********************************************************************/
  
#include "read_cbf.h"

#include <stdlib.h>
#include <stdio.h>

int main (int argc, char *argv [])
{
  int count, error;

  int        *image;

  char        detector_type [32];
  int         slow_pixels;
  int         fast_pixels;
  double      slow_size;
  double      fast_size;
  double      slow_direction [3];
  double      fast_direction [3];
  double      wavelength;
  double      e_vector [3];
  double      polarization;
  double      divergence_x;
  double      divergence_y;
  double      distance;
  double      slow_center;
  double      fast_center;
  double      axis [3];
  double      start;
  double      rotation;
  double      gain;
  int         overload;
  int         debug;


    /* Allocate space for an image up to 8192 x 8192 */
    
  image = malloc (8192 * 8192 * sizeof(int));
  
  if (!image)
  {
    fprintf (stderr, " ERROR allocating space for image\n");
    
    exit (1);
  }


    /* Read each file on the command line */
    
  for (count = 1; count < argc; count++)
  {
    error = read_flat_raster_cbf (argv [count],
                                  image,
                                  8192 * 8192,
                                  detector_type,
                                  &slow_pixels,
                                  &fast_pixels,
                                  &slow_size,
                                  &fast_size,
                                  slow_direction,
                                  fast_direction,
                                  &wavelength,
                                  e_vector,
                                  &polarization,
                                  &divergence_x,
                                  &divergence_y,
                                  &distance,
                                  &slow_center,
                                  &fast_center,
                                  axis,
                                  &start,
                                  &rotation,
                                  &gain,
                                  &overload,
                                  1);

    if (error)
    {
      fprintf (stderr, " ERROR %x in read of \"%s\"\n", 
                         error, argv [count]);
                       
      exit (2);
    }
    
    
      /* Print the parameters */  
   
    printf ("\n");
    printf (" Image name:          \"%s\"\n", argv [count]);
    printf (" Detector type:       \"%s\"\n", detector_type);
    printf (" Image dimensions:    %d x %d\n", slow_pixels, fast_pixels);
    printf (" Pixel dimensions:    %8.2e m x %8.2e m\n", slow_size, fast_size);
    printf (" Slow direction:      (%.4f %.4f %.4f)\n", slow_direction [0],
                                                        slow_direction [1],
                                                        slow_direction [2]);
    printf (" Fast direction:      (%.4f %.4f %.4f)\n", fast_direction [0],
                                                        fast_direction [1],
                                                        fast_direction [2]);
    printf (" Wavelength:          %8.2e m\n", wavelength);
    printf (" Polarization vector: (%.4f %.4f %.4f)\n", e_vector [0],
                                                        e_vector [1],
                                                        e_vector [2]);
    printf (" Polarization ratio:  %.4f\n", polarization);
    printf (" Divergence:          (%.4f %.4f)\n", divergence_x, divergence_y);
    printf (" Detector distance:   %.4f m\n", distance);
    printf (" Beam center:         (%.4f %.4f)\n", slow_center, fast_center);
    printf (" Rotation axis:       (%.4f %.4f %.4f)\n", axis [0],
                                                        axis [1],
                                                        axis [2]);
    printf (" Starting rotation:   %.4f degrees\n", start);
    printf (" Rotation range:      %.4f degrees\n", rotation);
    printf (" Detector gain:       %.4f\n", gain);
    printf (" Pixel overload:      %d\n", overload);
  }  
}
