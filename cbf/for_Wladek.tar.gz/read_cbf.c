  /* Function to read a CBF image and experimental parameters 
 
     This function will read a CBF image into the int array "image".
     
     The function returns 0 on success and a CBF_xxx code on failure.
     
     If the image array is too small for the image, the function returns -1.
     
     NOTE: the detector is assumed to be a single surface consisting of a
           regular 2-dimensional raster.

     Parameters:

       image_name     (const char *): image file name     
       image          (int *):        array destination for the image
       image_size     (size_t):       size in ints of the destination array
       detector_type  (char *):       string destination for detector type 
                                      (assumed at least 32 characters long)
       slow_pixels    (size_t *):     number of pixels in the slow direction
       fast_pixels    (size_t *):     number of pixels in the fast direction
       slow_size      (double *):     pixel size in the slow direction (m)
       fast_size      (double *):     pixel size in the fast direction (m)
       slow_direction (double *):     3-d normalised slow direction vector
       fast_direction (double *):     3-d normalised fast direction vector
       wavelength     (double *):     wavelength (m)
       e_vector       (double *):     3-d normalised electric field vector
       polarization   (double *):     x-ray beam polarisation factor
       divergence_x   (double *):     divergence in the x direction (degrees)
       divergence_y   (double *):     divergence in the y direction (degrees)
       distance       (double *):     detector distance (m)
       slow_center    (double *):     slow pixel coordinate of beam center
       fast_center    (double *):     fast pixel coordinate of beam center
       axis           (double *):     3-d normalised rotation axis
       start          (double *):     starting rotation angle (degrees)
       rotation       (double *):     rotation range (degrees)
       gain           (double *):     detector gain (counts/x-ray photon)
       overload       (int *):        pixel overload value
       debug          (int):          print error messages if non-0

     NULL is permitted for any pointer parameter.
     
     Numerical values missing from the CBF file are set to 0.
     String values missing from the CBF file are set to "UNKNOWN".
  
  */
  
#ifdef __cplusplus

extern "C" {

#endif

#include "read_cbf.h"

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int read_flat_raster_cbf (const char *image_name,
                          int        *image,
                          size_t      image_size,
                          char        detector_type [32],
                          int        *slow_pixels,
                          int        *fast_pixels,
                          double     *slow_size,
                          double     *fast_size,
                          double      slow_direction [3],
                          double      fast_direction [3],
                          double     *wavelength,
                          double      e_vector [3],
                          double     *polarization,
                          double     *divergence_x,
                          double     *divergence_y,
                          double     *distance,
                          double     *slow_center,
                          double     *fast_center,
                          double      axis [3],
                          double     *start,
                          double     *rotation,
                          double     *gain,
                          int        *overload,
                          int         debug)
{
  FILE *in;

  cbf_handle cbf;
  
  cbf_detector detector;
  
  cbf_goniometer goniometer;

  int error, count;
  
  size_t dimension [2];
  
  const char *type;

  double d10 [3], d01 [3], c00 [3], c10 [3], c01 [3], l10, l01, 
         ovl, ratio, norm;


    /* Open the file */

  in = fopen (image_name, "rb");

  if (!in)
  {
    if (debug)
    
      fprintf (stderr, " Couldn't open the CBF file \"%s\"\n", image_name);

    return (CBF_FILEOPEN);
  }


    /* Create the cbf handle for the image file */

  error = cbf_make_handle (&cbf);
  
  if (error)
  {
    if (debug)
    
      fprintf (stderr, " CBFLIB ERROR %x creating handle for \"%s\"\n", 
                         error, image_name);

    fclose (in);

    return (error);
  }
  

    /* Read as CBF format */

  error = cbf_read_file (cbf, in, MSG_DIGESTNOW);

  if (error)
  {
    if (debug)
    
      fprintf (stderr, " CBFLIB ERROR %x reading \"%s\"\n", 
                         error, image_name);

    return (error | cbf_free_handle (cbf));
  }


    /* Point the parser at the first datablock */

  error = cbf_rewind_datablock (cbf);

  if (error)
  {
    if (debug)
    
      fprintf (stderr, " CBFLIB ERROR %x rewinding datablock in \"%s\"\n", 
                         error, image_name);

    return (error | cbf_free_handle (cbf));
  }


    /* Get the image dimensions (first = slow, second = fast) */

  error = cbf_get_image_size (cbf, 0, 0, &dimension [0], &dimension [1]);
  
  if (error)
  {
    if (debug)
    
      fprintf (stderr, " CBFLIB ERROR %x parsing image dimensions in \"%s\"\n",
                         error, image_name);

    return (error | cbf_free_handle (cbf));
  }
  
  if (slow_pixels)
  
    *slow_pixels = dimension [0];

  if (fast_pixels)
  
    *fast_pixels = dimension [1];

  
    /* Wavelength */
    
  if (wavelength)
  {
    error = cbf_get_wavelength (cbf, wavelength);
    
    if (error)
    {
      if (debug)
    
        fprintf (stderr, " CBFLIB ERROR %x reading wavelength in \"%s\"\n",
                           error, image_name);
                           
      if (error == CBF_NOTFOUND)
    
        *wavelength = 0;
        
      else
      
        return (error | cbf_free_handle (cbf));
    }
    
    *wavelength *= 1E-10;
  }


    /* Polarization */
    
  if (e_vector || polarization)
  {
    error = cbf_get_polarization (cbf, &ratio, &norm);
    
    if (error)
    {
      if (debug)
    
        fprintf (stderr, " CBFLIB ERROR %x reading polarization in \"%s\"\n",
                           error, image_name);
                           
      if (error == CBF_NOTFOUND && !e_vector)
    
        *polarization = 0;
        
      else

        return (error | cbf_free_handle (cbf));
    }
    else
    {
      if (polarization)
      
        *polarization = ratio;
        
      if (e_vector)
      {
        e_vector [0] =  cos (norm * 0.017453292519943295769);
        e_vector [1] = -sin (norm * 0.017453292519943295769);
        e_vector [2] =  0;
      }
    }
  }
        
  
    /* Divergence */
    
  if (divergence_x || divergence_y)
  {
    error = cbf_get_divergence (cbf, divergence_x, divergence_y, NULL);
    
    if (error)
    {
      if (debug)
    
        fprintf (stderr, " CBFLIB ERROR %x reading divergence in \"%s\"\n",
                           error, image_name);
                           
      if (error == CBF_NOTFOUND)
      {
        if (divergence_x)
        
          *divergence_x = 0;
    
        if (divergence_y)
        
          *divergence_y = 0;
      }
      else
      
        return (error | cbf_free_handle (cbf));
    }
  }


    /* Gain */

  if (gain)
  {
    error = cbf_get_gain (cbf, 0, gain, NULL);
  
    if (error)
    {
      if (debug)
    
        fprintf (stderr, " CBFLIB ERROR %x reading gain in \"%s\"\n",
                           error, image_name);
                           
      if (error == CBF_NOTFOUND)
    
        *gain = 0;
        
      else
      
        return (error | cbf_free_handle (cbf));
    }
  }


    /* Overload value */
      
  if (overload)
  {
    error = cbf_get_overload (cbf, 0, &ovl);
  
    if (error)
    {
      if (debug)
    
        fprintf (stderr, " CBFLIB ERROR %x reading overload in \"%s\"\n",
                           error, image_name);
                           
      if (error == CBF_NOTFOUND)
    
        *overload = 0;
        
      else
      
        return (error | cbf_free_handle (cbf));
    }
    else
    
      *overload = ovl;
  }


    /* Detector type */
    
  if (detector_type)
  {
    error = cbf_find_category (cbf, "diffrn_detector");
    
    if (!error)
  
      error = cbf_find_column (cbf, "type");
      
    if (!error)

      error = cbf_get_value (cbf, &type);
      
    if (error)
    {
      if (debug)
    
        fprintf (stderr, " CBFLIB ERROR %x reading detector type in \"%s\"\n",
                           error, image_name);
                           
      if (error == CBF_NOTFOUND)
      
        strcpy (detector_type, "UNKNOWN");
        
      else
      
        return (error | cbf_free_handle (cbf));
    }
        
    else
    {
      for (count = 0; *type && count < 31; *type++)
        
        if (isalnum (*type))
          
          detector_type [count++] = toupper (*type);

      detector_type [count] = '\0';
    }
  }


    /* Construct detector object */

  error = cbf_construct_detector (cbf, &detector, 0);

  if (error)
  {
    if (debug)
    
      fprintf (stderr, 
               " CBFLIB ERROR %x parsing detector parameters in \"%s\"\n",
                         error, image_name);

    return (error | cbf_free_handle (cbf));
  }


      /* Crystal to detector distance */
      
  if (distance)
  {
    error = cbf_get_detector_distance (detector, distance);
    
    if (error)
    
      if (error == CBF_NOTFOUND)
    
        *distance = 0;
        
      else
      
        return (error | cbf_free_detector (detector) | cbf_free_handle (cbf));

    else
    
      *distance *= 0.001;
  }      
    
  
      /* Beam center */
      
  if (slow_center || fast_center)
  {
    error = cbf_get_beam_center (detector, slow_center, fast_center,
                                           NULL, NULL);
    
    if (error)
    
      if (error == CBF_NOTFOUND)
      {
        if (slow_center)
        
          *slow_center = 0;
          
        if (fast_center)
        
          *fast_center = 0;
      }
      else
      
        return (error | cbf_free_detector (detector) | cbf_free_handle (cbf));
  }      
    
  
    /* Get 3-dimensional pixel coordinates for (0,0) (1,0) (0,1) */
    
  d10 [0] = d10 [1] = d10 [2] = 0;
  d01 [0] = d01 [1] = d01 [2] = 0;

  error = cbf_get_pixel_coordinates (detector, 0, 0, 
                                     &c00 [0], &c00 [1], &c00 [2]);
                                     
  if (!error)
  
    error = cbf_get_pixel_coordinates (detector, 1, 0, 
                                     &c10 [0], &c10 [1], &c10 [2]);
                                     
  if (!error)
  
    error = cbf_get_pixel_coordinates (detector, 0, 1, 
                                     &c01 [0], &c01 [1], &c01 [2]);

  if (error)
  {
    if (debug)
    
      fprintf (stderr, 
               " CBFLIB ERROR %x calculating pixel coordinates in \"%s\"\n",
                         error, image_name);

    return (error | cbf_free_detector (detector) | cbf_free_handle (cbf));
  }


    /* Free the detector handle */
    
  error = cbf_free_detector (detector);
  
  if (error)
  {
    if (debug)
    
      fprintf (stderr, " CBFLIB ERROR %x freeing detector handle in \"%s\"\n",
                         error, image_name);

    return (error | cbf_free_handle (cbf));
  }


    /* Calculate 3-dimensional deltas from (0,0) to (1,0) and (0,1) */
    
  d10 [0] = c10 [0] - c00 [0];
  d10 [1] = c10 [1] - c00 [1];
  d10 [2] = c10 [2] - c00 [2];

  d01 [0] = c01 [0] - c00 [0];
  d01 [1] = c01 [1] - c00 [1];
  d01 [2] = c01 [2] - c00 [2];


    /* Calculate pixel edge dimensions and normalise the edge vectors */

  l10 = sqrt (d10 [0] * d10 [0] + d10 [1] * d10 [1] + d10 [2] * d10 [2]);
  l01 = sqrt (d01 [0] * d01 [0] + d01 [1] * d01 [1] + d01 [2] * d01 [2]);

  if (l10 <= 0 || l01 <= 0)
  {
    if (debug)
    
      fprintf (stderr, 
               " CBFLIB ERROR %x calculating pixel dimensions in \"%s\"\n",
                         error, image_name);

    return (CBF_UNDEFINED | cbf_free_handle (cbf));
  }
            
  d10 [0] /= l10;
  d10 [1] /= l10;
  d10 [2] /= l10;
    
  d01 [0] /= l01;
  d01 [1] /= l01;
  d01 [2] /= l01;
  
  if (slow_size)
  
    *slow_size = l10 * 1E-3;
    
  if (fast_size)
  
    *fast_size = l01 * 1E-3;

  if (slow_direction)
  {
    slow_direction [0] = d10 [0];
    slow_direction [1] = d10 [1];
    slow_direction [2] = d10 [2];
  }

  if (fast_direction)
  {
    fast_direction [0] = d01 [0];
    fast_direction [1] = d01 [1];
    fast_direction [2] = d01 [2];
  }


    /* Oscillation vector, starting angle and rotation */

  error = cbf_construct_goniometer (cbf, &goniometer);

  if (error)
  {
    if (debug)
    
      fprintf (stderr, 
               " CBFLIB ERROR %x parsing goniometer parameters in \"%s\"\n",
                         error, image_name);

    return (error | cbf_free_handle (cbf));
  }

  if (axis)
  {
    error = cbf_get_rotation_axis (goniometer, 0, 
                                   &axis [0], &axis [1], &axis [2]);

    if (error)
    {
      if (debug)
    
        fprintf (stderr, 
                 " CBFLIB ERROR %x reading rotation axis in \"%s\"\n",
                         error, image_name);

      return (error | cbf_free_goniometer (goniometer)
                    | cbf_free_handle (cbf));
    }
  }

  if (start || rotation)
  {
    error = cbf_get_rotation_range (goniometer, 0, start, rotation);
    
    if (error)
    {
      if (debug)
    
        fprintf (stderr, 
                 " CBFLIB ERROR %x reading rotation range in \"%s\"\n",
                         error, image_name);

      if (error == CBF_NOTFOUND)
      {
        if (start)
        
          *start = 0;
          
        if (rotation)
        
          *rotation = 0;
      }
      else
      
        return (error | cbf_free_goniometer (goniometer) 
                      | cbf_free_handle (cbf));
    }
  }


    /* Free the goniometer handle */
    
  error = cbf_free_goniometer (goniometer);

  if (error)
  {
    if (debug)
    
      fprintf (stderr, 
               " CBFLIB ERROR %x freeing goniometer handle in \"%s\"\n",
                       error, image_name);

    return (error | cbf_free_handle (cbf));
  }
  
  
    /* Read the image data */
    
  if (dimension [0] * dimension [1] > image_size)
  {
    if (debug)
    
      fprintf (stderr, " READ ERROR %x array too small for image in \"%s\"\n",
                         -1, image_name);

    return (-1 | cbf_free_handle (cbf));
  }
      
  error = cbf_get_image (cbf, 0, 0, image, 
                                sizeof(int), 1, dimension [0], dimension [1]);
  
  if (error)
  {
    if (debug)
    
      fprintf (stderr, " CBFLIB ERROR %x reading image data from \"%s\"\n", 
                         error, image_name);

    return (error | cbf_free_handle (cbf));
  }


    /* Free the cbf handle */
      
  error = cbf_free_handle (cbf);

  if (error)
  {
    if (debug)
    
      fprintf (stderr, " CBFLIB ERROR %x freeing CBF handle for \"%s\"\n", 
                         error, image_name);

    return (error);
  }


    /* Success */

  return 0;
}

#ifdef __cplusplus

}

#endif
