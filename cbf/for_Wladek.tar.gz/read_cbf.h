
#ifndef READ_CBF_H
#define READ_CBF_H

#ifdef __cplusplus

extern "C" {

#endif

#include "cbf_simple.h"

int read_flat_raster_cbf (const char *image_name,
                          int        *image,
                          size_t      image_size,
                          char        detector_type [32],
                          int        *slow_pixels,
                          int        *fast_pixels,
                          double     *slow_size,
                          double     *fast_size,
                          double      slow_direction [3],
                          double      fast_direction [3],
                          double     *wavelength,
                          double      e_vector [3],
                          double     *polarisation,
                          double     *divergence_x,
                          double     *divergence_y,
                          double     *distance,
                          double     *slow_center,
                          double     *fast_center,
                          double      axis [3],
                          double     *start,
                          double     *rotation,
                          double     *gain,
                          int        *overload,
                          int         debug);

#ifdef __cplusplus

}

#endif

#endif /* READ_CBF_H */

