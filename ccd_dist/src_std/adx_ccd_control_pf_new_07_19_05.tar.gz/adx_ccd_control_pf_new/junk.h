	case H_UP_HALFSLIT:
		break;
	case V_UP_HALFSLIT:
		break;
	case H_DN_HALFSLIT:
		break;
	case V_DN_HALFSLIT:
		break;
	case V_MANSLIT:
		break;
	case H_MANSLIT:
