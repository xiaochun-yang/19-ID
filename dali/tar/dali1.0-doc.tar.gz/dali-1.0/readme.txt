Dali VM Release 1.0
-------------------

dali-1.0-src.tar.gz   : Source codes (unix version)
dali-1.0-src.zip      : Source codes (windows version)
dali-1.0-doc.zip      : Documentations in HTML format.  For the latest
                        version of the documentations, please visit our 
			web site at http://www.cs.cornell.edu/dali
dali-1.0-eg.tar.gz    : Dali examples in C and Tcl.
dali-1.0-bin.tar.gz   : Binaries and header files. (unix versoin)
dali-1.0-bin.zip      : Binaries and header files. (windows version)
