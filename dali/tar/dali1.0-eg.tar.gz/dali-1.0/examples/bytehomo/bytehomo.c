/*------------------------------------------------------------------------
 *
 * Copyright (c) 1997-1998 by Cornell University.
 * 
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * bytehomo.c
 *
 * Usage : bytehomo inputPGM outputPGM
 *
 * Given an input PPM file, perform homogeneous transformation on the input.
 * Image will be transformed to a trapeziod with top = TARGET_WIDTH
 * bottom = TARGET_WIDTH - 50 and height = TARGET_HEIGHT;
 *
 *------------------------------------------------------------------------
 */
#include "dvmbasic.h"
#include "dvmbytegeom.h"
#include "dvmpnm.h"

#define TARGET_WIDTH  200
#define TARGET_HEIGHT 100

void ReadPGM(char *, PnmHdr **, ByteImage **);
void WritePGM(PnmHdr *, ByteImage *, char *);

int main(int argc, char *argv[])
{
    PnmHdr *hdr;
    ByteImage *buf, *newbuf;
    int w, h;
    double a, b, d, e, m, n;

    /*
     * Parse the arguments, and read the input PGM.
     */
    if (argc != 3) {
        fprintf(stderr, "usage : %s input output\n", argv[0]);
	exit(1);
    }
    ReadPGM (argv[1], &hdr, &buf);

    /*
     * Compute the homogeneuos transformation matrix.
     */
    w = PnmHdrGetWidth (hdr);
    h = PnmHdrGetHeight (hdr);
    ByteHomoComputeMatrix (w, h, 
    	TARGET_WIDTH, 0, TARGET_WIDTH - 50, TARGET_HEIGHT, 50, TARGET_HEIGHT,
	&a, &b, &d, &e, &m, &n);

    /*
     * Allocate the output image and set the color to black.
     */
    newbuf = ByteNew(TARGET_WIDTH, TARGET_HEIGHT);
    ByteSet(newbuf, 0);

    /*
     * Perform the actual transformation.
     */
    ByteHomo(buf, newbuf, a, b, 0, d, e, 0, m, n, 1);

    /*
     * Initialize the PnmHdr to the new width and height.
     */
    PnmHdrSetWidth (hdr, TARGET_WIDTH);
    PnmHdrSetHeight (hdr, TARGET_HEIGHT);

    /*
     * Output the image as an PGM file.
     */
    WritePGM (hdr, newbuf, argv[2]);

    /*
     * Clean up.
     */
    ByteFree(newbuf);
    ByteFree(buf);
    PnmHdrFree(hdr);

    return 0;
}
