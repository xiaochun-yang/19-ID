/*------------------------------------------------------------------------
 *
 * Copyright (c) 1997-1998 by Cornell University.
 * 
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * Steve Weiss sweiss@cs.cornell.edu
 *
 * Usage : canny inputPGM outputPBM
 * Dimension if inputPGM must be multiples of 8.
 *
 * Performs Canny edge detection on the input image.
 *------------------------------------------------------------------------
 */
#include <dvmbasic.h>
#include <dvmpnm.h>
#include <dvmvision.h>

void ReadPGM(char *, PnmHdr **, ByteImage **);
void WritePBM8(PnmHdr *, BitImage *, char *);

int main(int argc, char *argv[])
{
    PnmHdr *hdr;
    ByteImage *buf, *smth;
    BitImage *bit1;
    int w, h;

    /*
     * Check the arguments.
     */
    if (argc != 3) {
        fprintf(stderr, "usage : %s input output\n", argv[0]);
	exit(1);
    }

    /*
     * Read the input image.
     */
    ReadPGM (argv[1], &hdr, &buf);
    w = PnmHdrGetWidth (hdr);
    h = PnmHdrGetHeight (hdr);
    

    /*
     * First, smooth the input image.
     */
    smth = ByteNew(w, h);
    ByteSmooth(buf, smth, 2);

    /*
     * Perform Canny edge detection.
     */
    ByteEdgeDetectCanny(smth, buf, 5, 10);
    ByteFree(smth);

    /*
     * Convert the edge detected image into a B&W bit image, and output it.
     */
    bit1 = BitNew(w, h);
    BitMakeFromThreshold8(buf, bit1, 128, 0);
    WritePBM8(hdr, bit1, argv[2]);
    BitFree(bit1);

    return 0;
}
