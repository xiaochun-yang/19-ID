/*------------------------------------------------------------------------
 *
 * Copyright (c) 1997-1998 by Cornell University.
 * 
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * changevol.c
 *
 * Haye Hsi Chan haye@cs.cornell.edu
 *
 * Usage : changevol inputWav outputWav
 * 
 * Takes in a stereo, 8-bit, pcm wav files, and double the volume of the
 * left channel.
 *------------------------------------------------------------------------
 */
#include <dvmbasic.h>
#include <dvmamap.h>
#include <dvmwave.h>

void ReadWave (char *, WaveHdr ** hdr, Audio ** audio, BitStream ** inbs);
void WriteWave (WaveHdr * hdr, Audio * audio, char *);

int 
main (int argc, char *argv[])
{
    AudioMap *map;
    unsigned char list[255];
    int i;
    WaveHdr *hdr;
    Audio *audio;
    BitStream *inbs;

    /*
     * Parse the arguments.
     */
    if (argc != 3) {
	fprintf (stderr, "%s input output\n", argv[0]);
	exit (1);
    }

    /*
     * Initialize the volumn-change mappings.
     * This maps i -> 2i - 128, clipped at 0 and 255
     */
    for (i = 0; i < 256; i++) {
	int v;

	v = i + i - 128;
	if (v < 0)
	    list[i] = 0;
	else if (v > 255)
	    list[i] = 255;
	else
	    list[i] = v;
    }
    map = AudioMap8To8New ();
    AudioMap8To8InitCustom (list, map);

    /*
     * Read in the input wav file, apply the mapping and write it out.
     */
    ReadWave (argv[1], &hdr, &audio, &inbs);
    AudioMap8To8ApplySome (map, audio, 0, 2, 0, 2, audio);
    WriteWave (hdr, audio, argv[2]);

    /*
     * Clean up stuffs.
     */
    BitStreamFree (inbs);
    AudioFree (audio);
    AudioMapFree (map);
    WaveHdrFree (hdr);

    return 0;
}
