/*------------------------------------------------------------------------
 *
 * Copyright (c) 1997-1998 by Cornell University.
 * 
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * histequal.c  
 *
 * Matthew Chiu machiu@cs.cornell.edu
 *
 * Perform histogram equalization on a PGM file.
 *
 *------------------------------------------------------------------------
 */

#include "dvmbasic.h"
#include "dvmpnm.h"
#include "dvmimap.h"

void ReadPGM (char *, PnmHdr **, ByteImage **);
void WritePGM (PnmHdr *, ByteImage *, char *);

int main(int argc, char *argv[])
{
    PnmHdr* hdr;
    ByteImage *image, *histImage;
    ImageMap *histMap;

    /*
     * Check the arguments.
     */
    if (argc != 3) {
        fprintf(stderr, "usage : %s input output\n", argv[0]);
	exit(1);
    }
    ReadPGM (argv[1], &hdr, &image);
    histImage = ByteNew(PnmHdrGetWidth(image), PnmHdrGetHeight(image));

    /* 
     * create the histogram equalization maps
     */
    histMap = ImageMapNew();
    ImageMapInitHistoEqual(image,histMap);
    ImageMapApply(histMap,image,histImage);

    /*
     * write the resultant image out to disk
     */
    WritePGM(hdr, histImage, argv[2]);

    /*
     * Free up any memory blocks
     */
    ImageMapFree(histMap);
    ByteFree(image);
    ByteFree(histImage);
    PnmHdrFree(hdr);

    return 0;
}
