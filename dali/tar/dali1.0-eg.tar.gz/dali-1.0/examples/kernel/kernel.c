/*------------------------------------------------------------------------
 *
 * Copyright (c) 1997-1998 by Cornell University.
 * 
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * kernel.c
 *
 * Matthew Chiu machiu@cs.cornell.edu
 *
 * Usage : kernel inputPGM outputPGM
 *
 * Perform a convolution on the input PGM.
 *
 *------------------------------------------------------------------------
 */
#include "dvmbasic.h"
#include "dvmpnm.h"
#include "dvmkernel.h"

void ReadPGM(char *, PnmHdr **, ByteImage **);
void WritePGM(PnmHdr *, ByteImage *, char *);

int main(int argc, char *argv[])
{
    PnmHdr *hdr;
    ByteImage *byte, *t1, *t2, *result;
    int w, h;
    Kernel *k;
    int table[4][4] = {{1, 1, 1, 1}, {1, 0, 0, 1}, {1, 0, 0, 1}, {1, 1, 1, 1}};

    if (argc < 2) {
        fprintf(stderr, "usage : %s input output", argv[0]);
	exit(1);
    }
    
    /*
     * Read the input image.
     */
    ReadPGM(argv[1], &hdr, &byte);

    /*
     * Initialize the convolution kernel.
     */
    k = KernelNew(4, 4);
    KernelSetValues(k, &(table[0][0]));
    KernelSetDivFactor(k, 12);
    KernelSetOffset(k, 0);

    /*
     * Prepare the output image.
     */
    w = PnmHdrGetWidth(hdr);
    h = PnmHdrGetHeight(hdr);
    t1 = ByteNew(w+3, h+3);
    t2 = ByteClip(t1, 2, 2, w, h);
    ByteCopy(byte, t2);
    ByteExtend(t1, 3, 3);
    
    /*
     * Performs the convolution.
     */
    result = ByteNew(w, h);
    KernelApply(k, t1, result);

    /*
     * Output the result.
     */
    WritePGM(hdr, result, argv[2]);

    /*
     * Clean up and we are done.
     */
    ByteFree(result);
    ByteFree(byte);
    ByteFree(t1);
    ByteFree(t2);
    KernelFree(k);
    PnmHdrFree(hdr);

    return 0;
}
