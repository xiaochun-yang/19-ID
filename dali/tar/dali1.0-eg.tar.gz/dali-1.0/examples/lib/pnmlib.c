/*------------------------------------------------------------------------
 *
 * Copyright (c) 1997-1998 by Cornell University.
 * 
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 *------------------------------------------------------------------------
 */
#include <dvmbasic.h>
#include <dvmpnm.h>
#include <sys/stat.h>

int fsize (char *name)
{
#ifdef __WIN32__
     struct _stat s;
#else
     struct stat s;
#endif
     int result;

     result = stat(name, &s);
     return s.st_size;
}

void WritePPM(hdr, r, g, b, filename)
    PnmHdr *hdr;
    ByteImage *r;
    ByteImage *g;
    ByteImage *b;
    char *filename;
{
    int w = ByteGetWidth(r);
    int h = ByteGetHeight(r);
    BitParser *bp = BitParserNew();
    BitStream *bs = BitStreamNew(20 + 3*w*h);
    FILE *f = fopen(filename, "wb");

    BitParserWrap(bp, bs);
    if (f == NULL) {
	fprintf(stderr, "unable to open file %s for writing.\n", filename);
	exit(1);
    }
    PnmHdrSetWidth(hdr, w);
    PnmHdrSetHeight(hdr, h);
    PnmHdrSetType(hdr, PPM_BIN);
    PnmHdrSetMaxVal(hdr, 255);
    PnmHdrEncode(hdr, bp);
    PpmEncode(r, g, b, bp);
    BitStreamFileWrite(bs, f, 0);
    fclose(f);
    BitParserFree(bp);
    BitStreamFree(bs);
}

void ReadPPM (filename, hdr, r, g, b)
    char *filename;
    PnmHdr **hdr;
    ByteImage **r;
    ByteImage **g;
    ByteImage **b;
{
    FILE *f;
    BitStream *inbs;
    BitParser *inbp;
    int w, h;

    f = fopen(filename, "rb");
    if (f == NULL) {
	fprintf(stderr, "unable to open file %s for reading\n", filename);
	exit(1);
    }
    *hdr = PnmHdrNew();
    inbs = BitStreamNew(fsize(filename));
    inbp = BitParserNew();
    BitParserWrap(inbp, inbs);
    BitStreamFileRead(inbs, f, 0);
    PnmHdrParse(inbp, *hdr);

    w = PnmHdrGetWidth(*hdr);
    h = PnmHdrGetHeight(*hdr);
    *r = ByteNew(w, h);
    *g = ByteNew(w, h);
    *b = ByteNew(w, h);
    PpmParse(inbp, *r, *g, *b);

    fclose(f);
    BitParserFree(inbp);
    BitStreamFree(inbs);

}


void WritePGM(hdr, r, filename)
    PnmHdr *hdr;
    ByteImage *r;
    char *filename;
{
    int w = ByteGetWidth(r);
    int h = ByteGetHeight(r);
    BitParser *bp = BitParserNew();
    BitStream *bs = BitStreamNew(20 + w*h);
    FILE *f = fopen(filename, "wb");

    BitParserWrap(bp, bs);
    if (f == NULL) {
	fprintf(stderr, "unable to open file %s for writing.\n", filename);
	exit(1);
    }
    PnmHdrSetWidth(hdr, w);
    PnmHdrSetHeight(hdr, h);
    PnmHdrSetType(hdr, PGM_BIN);
    PnmHdrSetMaxVal(hdr, 255);
    PnmHdrEncode(hdr, bp);
    PgmEncode(r, bp);
    BitStreamFileWrite(bs, f, 0);
    fclose(f);
    BitParserFree(bp);
    BitStreamFree(bs);
}

void ReadPGM (filename, hdr, r)
    char *filename;
    PnmHdr **hdr;
    ByteImage **r;
{
    FILE *f;
    BitStream *inbs;
    BitParser *inbp;
    int w, h;

    f = fopen(filename, "r");
    if (f == NULL) {
	fprintf(stderr, "unable to open file %s for reading\n", filename);
	exit(1);
    }
    *hdr = PnmHdrNew();
    inbs = BitStreamNew(fsize(filename));
    inbp = BitParserNew();
    BitParserWrap(inbp, inbs);
    BitStreamFileRead(inbs, f, 0);
    PnmHdrParse(inbp, *hdr);

    w = PnmHdrGetWidth(*hdr);
    h = PnmHdrGetHeight(*hdr);
    *r = ByteNew(w, h);
    PgmParse(inbp, *r);

    fclose(f);
    BitParserFree(inbp);
    BitStreamFree(inbs);
}


void WritePBM8(hdr, r, filename)
    PnmHdr *hdr;
    BitImage *r;
    char *filename;
{
    int w = BitGetWidth(r);
    int h = BitGetHeight(r);
    BitParser *bp = BitParserNew();
    BitStream *bs = BitStreamNew(20 + w*h/8);
    FILE *f = fopen(filename, "w");

    BitParserWrap(bp, bs);
    if (f == NULL) {
	fprintf(stderr, "unable to open file %s for writing.\n", filename);
	exit(1);
    }
    PnmHdrSetWidth(hdr, w);
    PnmHdrSetHeight(hdr, h);
    PnmHdrSetType(hdr, PBM_BIN);
    PnmHdrEncode(hdr, bp);
    PbmEncode8(r, bp);
    BitStreamFileWrite(bs, f, 0);
    fclose(f);
    BitParserFree(bp);
    BitStreamFree(bs);
}

void ReadPBM8 (filename, hdr, r)
    char *filename;
    PnmHdr **hdr;
    BitImage **r;
{
    FILE *f;
    BitStream *inbs;
    BitParser *inbp;
    int w, h;

    f = fopen(filename, "r");
    if (f == NULL) {
	fprintf(stderr, "unable to open file %s for reading\n", filename);
	exit(1);
    }
    *hdr = PnmHdrNew();
    inbs = BitStreamNew(fsize(filename));
    inbp = BitParserNew();
    BitParserWrap(inbp, inbs);
    BitStreamFileRead(inbs, f, 0);
    PnmHdrParse(inbp, *hdr);

    w = PnmHdrGetWidth(*hdr);
    h = PnmHdrGetHeight(*hdr);
    *r = BitNew(w, h);
    PbmParse8(inbp, *r);

    fclose(f);
    BitParserFree(inbp);
    BitStreamFree(inbs);
}
