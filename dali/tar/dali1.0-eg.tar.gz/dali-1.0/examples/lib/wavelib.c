/*------------------------------------------------------------------------
 *
 * Copyright (c) 1997-1998 by Cornell University.
 * 
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 *------------------------------------------------------------------------
 */
#include <dvmbasic.h>
#include <dvmwave.h>

void ReadWave (filename, hdr, audio, inbs)
    char *filename;
    WaveHdr **hdr;
    Audio **audio;
    BitStream **inbs;
{
    FILE *inf;
    int res, bytes, samples, offset, left;
    BitParser *inbp;

    inf = fopen(filename, "rb");
    if (inf == NULL) {
	fprintf(stderr, "unable to open %s for reading.\n", filename);
	exit(1);
    }
    *inbs = BitStreamNew(100);
    inbp = BitParserNew();
    BitParserWrap(inbp, *inbs);

    BitStreamFileRead(*inbs, inf, 0);
    *hdr = WaveHdrNew();
    WaveHdrParse(inbp, *hdr);
    
    res = WaveHdrGetBitsPerSample(*hdr);
    bytes = WaveHdrGetDataLen(*hdr);
    samples = (bytes << 3)/res;
    offset = BitParserTell(inbp);
    
    BitStreamShift(*inbs, offset);
    BitStreamResize(*inbs, bytes);
    BitParserWrap(inbp, *inbs);
    BitParserSeek(inbp, 0);

    left = BitStreamBytesLeft(*inbs, 0);
    BitStreamFileRead(*inbs, inf, left);
    
    if (res == 8) {
	*audio = BitStreamCastToAudio8(*inbs, 0, samples);
    } else {
	*audio = BitStreamCastToAudio16(*inbs, 0, samples);
    }
    fclose(inf);
    BitParserFree(inbp);
}

void WriteWave (hdr, audio, name) 
    WaveHdr *hdr;
    Audio *audio;
    char *name;
{
    FILE *outf;
    BitStream *hdrbs, *outbs;
    BitParser *hdrbp;
    int res;
    
    outf = fopen(name, "wb");
    hdrbs = BitStreamNew(100);
    hdrbp = BitParserNew();
    
    BitParserWrap(hdrbp, hdrbs);
    WaveHdrEncode(hdr, hdrbp);
    BitStreamFileWrite(hdrbs, outf, 0);
    
    res = WaveHdrGetBitsPerSample(hdr);
    if (res ==  8) {
	outbs = Audio8CastToBitStream(audio);
    } else {
	outbs = Audio16CastToBitStream(audio);
    }

    BitStreamFileWrite(outbs, outf, 0);
    fclose(outf);
    BitParserFree(hdrbp);
    BitStreamFree(hdrbs);
    BitStreamFree(outbs);
}
