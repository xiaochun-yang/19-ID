/*------------------------------------------------------------------------
 *
 * Copyright (c) 1997-1998 by Cornell University.
 * 
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * ulawtopcm.c
 *
 * Haye Hsi Chan haye@cs.cornell.edu
 * 
 * Converts a WAVE file in ulaw format to linear PCM format.
 *
 *------------------------------------------------------------------------
 */
#include <dvmbasic.h>
#include <dvmamap.h>
#include <dvmwave.h>

void ReadWave(char *, WaveHdr **, Audio **, BitStream **);
void WriteWave(WaveHdr *, Audio *, char *);

int main(int argc, char *argv[])
{

    AudioMap *map;
    WaveHdr *hdr;
    Audio *audio, *outaudio;
    BitStream *inbs;

    if (argc != 3) {
	fprintf(stderr, "usage : %s input output\n", argv[0]);
	exit(1);
    }
    ReadWave(argv[1], &hdr, &audio, &inbs);

    /*
     * We simply creates a u-law to linear mapping and apply the mapping.
     */
    map = AudioMap8To16New();
    AudioMap8To16InitULawToLinear(map);
    outaudio = Audio16New(AudioGetNumOfSamples(audio));
    AudioMap8To16Apply(map, audio, outaudio);

    /*
     * Initialize WAVE header and output the WAVE file.
     */
    WaveHdrSetFormat(hdr, 1);
    WaveHdrSetBitsPerSample(hdr, 16);
    WaveHdrSetBytesPerSec(hdr, WaveHdrGetBytesPerSec(hdr)*2);
    WaveHdrSetBlockAlign(hdr, WaveHdrGetBlockAlign(hdr)*2);
    WaveHdrSetDataLen(hdr, WaveHdrGetDataLen(hdr)*2);
    WriteWave(hdr, outaudio, argv[2]);

    WaveHdrFree(hdr);
    BitStreamFree(inbs);
    AudioFree(outaudio);
    AudioMapFree(map);

    return 0;
}
