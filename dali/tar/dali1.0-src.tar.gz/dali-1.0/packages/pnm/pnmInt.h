/*------------------------------------------------------------------------
 *
 * Copyright (c) 1997-1998 by Cornell University.
 * 
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 *------------------------------------------------------------------------
 */
/*
 *----------------------------------------------------------------------
 *
 * pnmioInt.h
 *
 *----------------------------------------------------------------------
 */

#ifndef _PNMIO_INT_
#define _PNMIO_INT_

#include "dvmpnm.h"


#endif
