/*------------------------------------------------------------------------
 *
 * Copyright (c) 1997-1998 by Cornell University.
 * 
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 *------------------------------------------------------------------------
 */
/*
 *----------------------------------------------------------------------
 *
 * templateInt.h
 *
 *----------------------------------------------------------------------
 */

#ifndef _TEMPLATE_INT_
#define _TEMPLATE_INT_

#include "rvmtemplate.h"
/*
 *  FILL IN HERE
 *
 *  List other includes here (possibly rvmbasic.h, or others)
 */

#endif
