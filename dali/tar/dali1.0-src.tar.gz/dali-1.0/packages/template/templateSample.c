/*------------------------------------------------------------------------
 *
 * Copyright (c) 1997-1998 by Cornell University.
 * 
 * See the file "license.txt" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 *------------------------------------------------------------------------
 */
/*
 *----------------------------------------------------------------------
 *
 * templateSample.c
 *
 *----------------------------------------------------------------------
 */

void
TemplateSample (x)
        int x;
{
    printf ("You just called the template sample function: %d\n", x);
}
