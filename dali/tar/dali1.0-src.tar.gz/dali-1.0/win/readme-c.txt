To use these libraries, put the include files in the include/
subdirectory, and the library files in the lib/ subdirectory,
in a place where your compiler can find them.

See the documentation, tutorial, and examples at 
    http://www.cs.cornell.edu/dali/
