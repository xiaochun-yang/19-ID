INSTALLATION GUIDE (Tcl)

    The Tcl script "install.tcl" is located in the Tcl subdirectory
        1. Start wish or tclsh
	2. Go to that directory using Tcl's "cd" command
	3. type "source install.tcl"

GETTING STARTED

    Take a look at the "Getting Started" guide at
    http://www.cs.cornell.edu/dali/tutorial/

