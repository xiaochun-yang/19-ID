#ifndef XIA_LINUX_H
#define XIA_LINUX_H

typedef int             HANDLE;
typedef unsigned char   UCHAR;
typedef unsigned short  USHORT;
typedef unsigned short* PUSHORT;
typedef unsigned int    ULONG;
typedef unsigned long*  PULONG;

#endif  /* XIA_LINUX_H */
